package com.example.sensores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    SensorManager sensorManager;
    private Button btnListar, btLuminosidade, btProximidade, btSair, btnAcele;
    private TextView resposta;
    public static MediaPlayer mp;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mp = MediaPlayer.create(this, R.raw.alarme);

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        btnListar = findViewById(R.id.listar);
        btProximidade = findViewById(R.id.btnProximidade);
        btLuminosidade = findViewById(R.id.btLuminosidade);
        btSair = findViewById(R.id.btSair);
        resposta = findViewById(R.id.resposta);
        btnAcele = findViewById(R.id.btAcelere);

        btnListar.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                String recebe = "";
                List<Sensor> listagem = sensorManager.getSensorList(Sensor.TYPE_ALL);

                for(int i = 0; i < listagem.size(); i++)
                {
                    recebe += listagem.get(i).getName() + "\n";
                }
                resposta.setText(" " + recebe);

            }
        });

        btProximidade.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                abrirProximidade();
            }
        });

        btLuminosidade.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                abrirLuminosidade();
            }
        });

        btSair.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Toast.makeText(MainActivity.this, "Volte Sempre!", Toast.LENGTH_SHORT).show();
                abriSair();

            }
        });
        btnAcele.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirAcele();
            }
        });
    }

    private void abrirProximidade()
    {
        Intent janela = new Intent(this, SensorProximidade.class);
        startActivity(janela);
    }

    private void abrirLuminosidade()
    {
        Intent janela = new Intent(this, SensorLuminosidade.class);
        startActivity(janela);
    }

    private void abriSair()
    {
        this.finishAffinity();
    }
    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Para Sair, Clique no botão Sair!", Toast.LENGTH_LONG).show();
    }
private void abrirAcele()
{
    Intent janelaa = new Intent(this, SensorAceleracao.class);
    startActivity(janelaa);
}

}