package com.example.sensores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Alarme extends AppCompatActivity {
    Button btnVoltarMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarme);

        btnVoltarMain = findViewById(R.id.btnVoltarMain);

        btnVoltarMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirMain();
            }
        });
        MainActivity.mp.start();
    }
    private void abrirMain()
    {
        Intent janela = new Intent(this, MainActivity.class);
        startActivity(janela);
        MainActivity.mp.stop();
    }
}