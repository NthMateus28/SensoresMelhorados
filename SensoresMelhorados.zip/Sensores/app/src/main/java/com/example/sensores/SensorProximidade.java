package com.example.sensores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

//declaração
public class SensorProximidade extends AppCompatActivity implements SensorEventListener {
    private TextView resultado;
    private Sensor proximidade;
    private SensorManager medir;
    private Button btnVoltar, btnLuminosidade, btnAceler;
    Vibrator vibrador;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor_proximidade);

        //mapeamento de todos os objetos do nosso layout
        medir = (SensorManager) this.getSystemService(SENSOR_SERVICE);
        proximidade = medir.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        resultado = findViewById(R.id.resultado);
        btnVoltar = findViewById(R.id.btnVoltar);
        vibrador = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        btnLuminosidade = findViewById(R.id.btnLuminosidade);
        btnAceler = findViewById(R.id.btnAceler);

//evetos de botões
        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirVoltar();
            }
        });
btnLuminosidade.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        abrirLuminosidade();
    }
});
btnAceler.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        abrirAceler();
    }
});
    }

    //chamada de callbacks, que tem a função de definir o cormportamento do ciclo dei vida das activities
    //onResume e onFalse
    @Override
    protected void onResume() {
        medir.registerListener(this, proximidade, SensorManager.SENSOR_DELAY_NORMAL);
        super.onResume();
    }

    @Override
    protected void onPause() {
        medir.unregisterListener(this, proximidade);
        super.onPause();
    }

    public void onSensorChanged(SensorEvent event) {
        if(event.values[0] == 0)
        {
            getWindow().getDecorView().setBackgroundColor(Color.BLUE);
            resultado.setText("ESTA MUITO PERTO");
            abrirAlarme();
        }
        else
        {
            getWindow().getDecorView().setBackgroundColor(Color.RED);
            resultado.setText("POR ENQUANTO TUDO SUAVE");
        }
        if (event.sensor.getType() == Sensor.TYPE_PROXIMITY)
        {


            if (event.values[0] == 0) {
                vibrador.vibrate(200);
                return;
            }
            else
            {
                vibrador.vibrate(1000);
            }
        }
    }

    public void abrirAlarme()
    {
        Intent janelar = new Intent(this, Alarme.class);
        startActivity(janelar);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    public void abrirVoltar() {
        Intent janela = new Intent(this, MainActivity.class);
        startActivity(janela);
    }
    public  void abrirLuminosidade(){
        Intent janelal = new Intent(this, SensorLuminosidade.class);
        startActivity(janelal);
    }
    public void abrirAceler()
    {
        Intent janelaa = new Intent(this, SensorAceleracao.class);
        startActivity(janelaa);
    }

    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Você não pode voltar!", Toast.LENGTH_LONG).show();
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}
