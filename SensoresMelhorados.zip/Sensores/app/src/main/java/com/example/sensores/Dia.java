package com.example.sensores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;

public class Dia extends AppCompatActivity
{
    Button btnVoltarMain2;
    private WebView imagem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dia);

        imagem = findViewById(R.id.imagem);

        WebSettings gif = imagem.getSettings();
        gif.setJavaScriptEnabled(true);
        String camilnho = "file:android_asset/gif.gif";
        imagem.loadUrl(camilnho);

        btnVoltarMain2 = findViewById(R.id.btnVoltarMain2);

        btnVoltarMain2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirMain();
            }
        });
    }
    private void abrirMain()
    {
        Intent janela = new Intent(this, MainActivity.class);
        startActivity(janela);
    }
}