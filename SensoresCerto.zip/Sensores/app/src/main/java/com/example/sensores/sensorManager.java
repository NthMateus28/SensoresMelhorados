package com.example.sensores;

public class sensorManager {
}
