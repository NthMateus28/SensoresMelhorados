package com.example.sensores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class SensorAceleracao extends AppCompatActivity implements SensorEventListener {
    private SensorManager sensorManager;
    //tipo de dado boleano para alterar a cor
    private boolean isColor = false;
    private TextView resultadoB;
    //igual ao double e que possui mais casa decimais = numero longo
    private long ultimaAtualizacao;
    private Button btnProxi, btnLumi, btnSair;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor_aceleracao);

        resultadoB = findViewById(R.id.resultadoB);
        resultadoB.setBackgroundColor(Color.BLUE);
        sensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
        ultimaAtualizacao = System.currentTimeMillis();
        btnProxi = findViewById(R.id.btnProxi);
        btnLumi = findViewById(R.id.btnLumi);
        btnSair = findViewById(R.id.btnSair);

        btnProxi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProxi();
            }
        });
        btnLumi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirLumi();
            }
        });
        btnSair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirMain();
            }
        });
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if(event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            getAccelerometer(event);
        }
    }
    private void getAccelerometer(SensorEvent event) {
        float[] values = event.values;
        //movimento
        float x = values [0];
        float y = values [1];
        float z = values [2];

        float accelationSquareRoot = (x * x + y * y + z * z) / (SensorManager.GRAVITY_EARTH * SensorManager.GRAVITY_EARTH);
        long tempoAtual = System.currentTimeMillis();

        Toast.makeText(getApplicationContext(), String.valueOf(accelationSquareRoot) + " " +
                SensorManager.GRAVITY_EARTH, Toast.LENGTH_SHORT).show();

        if(accelationSquareRoot >= 2)
        {
            if(tempoAtual - ultimaAtualizacao <200 )
            {
                return;
            }
            ultimaAtualizacao = tempoAtual;
            if(isColor)
            {
                resultadoB.setBackgroundColor(Color.BLUE);
            }
            else
            {
                resultadoB.setBackgroundColor(Color.RED);
            }
            isColor = ! isColor;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
                SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
    @Override
    public void onPointerCaptureChanged(boolean hasCapture){
    }
    public void abrirProxi()
    {
        Intent janela = new Intent(this, SensorProximidade.class);
        startActivity(janela);
    }
    public void abrirLumi()
    {
        Intent janelal = new Intent(this, SensorLuminosidade.class);
        startActivity(janelal);
    }
    public void abrirMain()
    {
        Intent janelam = new Intent(this, MainActivity.class);
        startActivity(janelam);
    }
}